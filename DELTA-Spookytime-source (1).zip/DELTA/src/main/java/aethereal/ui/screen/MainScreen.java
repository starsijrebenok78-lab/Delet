package aethereal.ui.screen;

import aethereal.render.ScaleUtil;
import aethereal.core.NativeMethodLookup;
import aethereal.ui.shader.GradientUtil;
import aethereal.ui.widget.EffectMarker;
import static aethereal.core.Interface.aM_;
import aethereal.core.Delta;
import aethereal.core.Interface;
import aethereal.core.InterfaceC0020Opcode;
import aethereal.render.EasingList;
import aethereal.render.Fonts;
import aethereal.render.ColorUtil;
import aethereal.util.MathUtil;

import aethereal.config.ThemeInfo;
import aethereal.render.Draw2DProcessor;
import aethereal.ui.screen.AltScreen;

import aethereal.render.AnimationUtil;
import aethereal.ui.element.Button;
import aethereal.api.Compile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.sound.MusicSound;
import net.minecraft.sound.MusicType;
import org.joml.Quaternionf;

public class MainScreen extends Screen {
    private static final float[] a;
    private static final String SPLASH_TEXT = "Delta была крякнута командой PasterEnd, а зафикшена @alex_s1gma, будьте счастливы";
    private static final float SPLASH_FADE_IN = 480.0f;
    private static final float SPLASH_TYPE_START = 320.0f;
    private static final float SPLASH_TYPE_TIME = 2800.0f;
    private static final float SPLASH_HOLD = 900.0f;
    private static final float SPLASH_FADE_OUT_AT = SPLASH_TYPE_START + SPLASH_TYPE_TIME + SPLASH_HOLD;
    private static final float SPLASH_FADE_OUT = 950.0f;
    private static boolean splashPlayed;
    private final AnimationUtil b;
    private final Button c;
    private final Button d;
    private final Button e;
    private final Button f;
    private final List<Button> g;
    private final List<EffectMarker.a> h;
    private float i;
    private float j;
    private float k;
    private float l;
    private final long m;
    private final boolean n;

    @Compile
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        this.b.a((Interface.aM_.currentScreen instanceof MainScreen) && q());
        this.b.a(0.0f, 1.0f, 0.15f, EasingList.g, delta);
        float fMin = Math.min(1.0f, this.b.c() / 0.9f);
        double dA = MathUtil.scale(mouseX, 2);
        double dA2 = MathUtil.scale(mouseY, 2);
        ScaleUtil.a(context, 2);
        int iMethod_4486 = Interface.aM_.getWindow().getScaledWidth();
        int iMethod_4502 = Interface.aM_.getWindow().getScaledHeight();
        a(context, iMethod_4486, iMethod_4502, (int) dA, (int) dA2, 1.25f - (EasingList.s.ease(fMin) * 0.2f));
        Delta.h().d().i().e().a(context.getMatrices());
        a(iMethod_4486, iMethod_4502);
        a(context, iMethod_4486 * 0.5f, ((iMethod_4502 - this.c.c()) * 0.5f) - 58.0f, fMin);
        Iterator<Button> it = this.g.iterator();
        while (it.hasNext()) {
            it.next().a(context, (int) dA, (int) dA2, delta, fMin);
        }
        a(context, fMin, (int) dA);
        EffectMarker.a(context.getMatrices(), delta, this.h);
        a(context, iMethod_4486, iMethod_4502);
        ScaleUtil.a(context);
    }

    @Compile
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (p()) {
            return true;
        }
        List<EffectMarker.a> list = this.h;
        List<Button> list2 = this.g;
        double dA = MathUtil.scale(mouseX, 2);
        double dA2 = MathUtil.scale(mouseY, 2);
        EffectMarker.a(list, (float) dA, (float) dA2);
        float f = this.k + 1.75f + (this.i * 59.5f);
        if (MathUtil.a(dA, dA2, f, this.l + 1.75f, 16.0f, 16.0f)) {
            this.j = ((float) dA) - f;
            return true;
        }
        for (Button button2 : list2) {
            if (button2.e() != null && MathUtil.a(dA, dA2, button2.f(), button2.g(), button2.b(), button2.c())) {
                button2.e().run();
                return true;
            }
        }
        return super.mouseClicked(dA, dA2, button);
    }

    @Compile
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        if (p()) {
            return true;
        }
        if (this.j >= 0.0f) {
            return true;
        }
        return super.mouseDragged(mouseX, mouseY, button, deltaX, deltaY);
    }

    @Compile
    public boolean mouseReleased(double mouseX, double mouseY, int button) {
        if (p()) {
            return true;
        }
        if (this.j < 0.0f) {
            return super.mouseReleased(mouseX, mouseY, button);
        }
        double dA = MathUtil.scale(mouseX, 2);
        float fMethod_15363 = MathHelper.clamp((((((float) dA) - this.j) - this.k) - 1.75f) / 59.5f, 0.0f, 1.0f);
        this.j = -1.0f;
        if (fMethod_15363 < 0.95f) {
            return true;
        }
        Interface.aM_.scheduleStop();
        return true;
    }

    static {
        NativeMethodLookup.lookup(MainScreen.class, 16);
        a = new float[2];
    }

    public MainScreen() {
        super(Text.empty());
        this.b = new AnimationUtil();
        this.h = new ArrayList();
        this.j = -1.0f;
        this.m = System.currentTimeMillis();
        this.n = !splashPlayed;
        splashPlayed = true;
        if (Interface.aM_.currentScreen instanceof MainScreen) {
            this.b.c(1.0f);
            this.b.d(1.0f);
            this.b.e(1.0f);
        }
        this.c = new Button(88.0f, 38.0f, "Одиночный Режим", () -> {
            Interface.aM_.setScreen(new SelectWorldScreen((Screen) null));
        });
        this.d = new Button(88.0f, 38.0f, "Сетевая Игра", () -> {
            Interface.aM_.setScreen(new MultiplayerScreen((Screen) null));
        });
        this.e = new Button(181.0f, 30.0f, "Выбор аккаунта", () -> {
            Interface.aM_.setScreen(new AltScreen());
        });
        this.f = new Button(79.0f, 19.5f, "Настройки", () -> {
            Interface.aM_.setScreen(new OptionsScreen((Screen) null, Interface.aM_.options));
        });
        this.g = List.of(this.c, this.d, this.e, this.f);
    }

    public MusicSound getMusic() {
        return MusicType.MENU;
    }

    public void close() {
    }

    public void renderBackground(DrawContext context, int mouseX, int mouseY, float delta) {
    }

    public static void a(DrawContext context, int width, int height, int mouseX, int mouseY, float scale) {
        float marginX = width * 0.025f;
        float marginY = height * 0.025f;
        float[] fArr = a;
        fArr[0] = fArr[0] + ((MathHelper.clamp((((mouseX / width) - 0.5f) * 2.0f) * marginX, (-marginX) * 0.9f, marginX * 0.9f) - a[0]) * 0.03f);
        float[] fArr2 = a;
        fArr2[1] = fArr2[1] + ((MathHelper.clamp((((mouseY / height) - 0.5f) * 2.0f) * marginY, (-marginY) * 0.9f, marginY * 0.9f) - a[1]) * 0.03f);
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(width / 2.0f, height / 2.0f, 0.0f);
        matrices.scale(scale, scale, 1.0f);
        matrices.translate((-width) / 2.0f, (-height) / 2.0f, 0.0f);
        Delta.h().d().i().a(matrices, Identifier.of("delta", "pictures/main.png"), (-marginX) + a[0], (-marginY) + a[1], width + (marginX * 2.0f), height + (marginY * 2.0f), 0.0f, -1);
        matrices.pop();
    }

    private void a(int width, int height) {
        float mainY = (height - this.c.c()) / 2.0f;
        float mainX = (((width - this.c.b()) - 5.0f) - this.d.b()) / 2.0f;
        this.c.a(mainX, mainY);
        this.d.a(mainX + this.c.b() + 5.0f, mainY);
        this.e.a((width - this.e.b()) / 2.0f, mainY + this.c.c() + 5.0f);
        this.k = (width - 79.0f) / 2.0f;
        this.l = height * 0.85f;
        this.f.a((width - this.f.b()) / 2.0f, (this.l - this.f.c()) - 5.0f);
    }

    private void a(DrawContext context, float open, int mouseX) {
        float target = this.j >= 0.0f ? MathHelper.clamp((((mouseX - this.j) - this.k) - 1.75f) / 59.5f, 0.0f, 1.0f) : 0.0f;
        this.i += (target - this.i) * 0.25f;
        float scale = 0.85f + (0.15f * EasingList.s.ease(open));
        Draw2DProcessor draw = Delta.h().d().i();
        MatrixStack matrices = context.getMatrices();
        matrices.push();
        matrices.translate(this.k + 39.5f, this.l + 9.75f, 0.0f);
        matrices.scale(scale, scale, 1.0f);
        matrices.translate((-this.k) - 39.5f, (-this.l) - 9.75f, 0.0f);
        float knobX = this.k + 1.75f + (this.i * 59.5f);
        float knobY = this.l + 1.75f;
        float centerX = knobX + 8.0f;
        float centerY = knobY + 8.0f;
        draw.b(matrices, this.k, this.l, 79.0f, 19.5f, 8.0f, ColorUtil.a(11, 11, 13, InterfaceC0020Opcode.bN), open);
        draw.a(matrices, this.k, this.l, 79.0f, 19.5f, 8.0f, 0.5f, ColorUtil.a(255, 255, 255, (int) (15.0f * open)));
        Fonts.e.c(matrices, "Выйти из игры", this.k + 9.0f, this.l + 5.75f, 7.0f, ColorUtil.a(ColorUtil.a(220, 80, 80, 255), this.i * open), ((knobX - 3.0f) - this.k) - 9.0f);
        int knob = ColorUtil.a(ColorUtil.a(255, 255, 255, 13), ColorUtil.a(220, 80, 80, 40), this.i);
        draw.a(matrices, knobX, knobY, 16.0f, 16.0f, 7.0f, ColorUtil.a(knob, (ColorUtil.b(knob)[3] / 255.0f) * open));
        matrices.push();
        matrices.translate(centerX, centerY, 0.0f);
        matrices.multiply(new Quaternionf().rotateZ((float) Math.toRadians((-90.0f) + (180.0f * this.i))));
        matrices.translate(-centerX, -centerY, 0.0f);
        Fonts.a.a(matrices, "c", (centerX - (Fonts.a.a("c", 8.5f) / 2.0f)) + 1.0f, centerY - 4.5f, 8.5f, ColorUtil.a(ColorUtil.a(-1, ColorUtil.a(220, 80, 80, 255), this.i), open));
        matrices.pop();
        matrices.pop();
    }

    private void a(DrawContext context, float centerX, float titleY, float open) {
        float titleWidth = Fonts.e.a("Delta Client", 12.0f);
        MatrixStack matrices = context.getMatrices();
        float scale = 0.85f + (0.15f * EasingList.s.ease(open));
        matrices.push();
        matrices.translate(centerX, titleY + 8.0f, 0.0f);
        matrices.scale(scale, scale, 1.0f);
        matrices.translate(-centerX, (-titleY) - 8.0f, 0.0f);
        int primary = Delta.h().d().o().a(ThemeInfo.PRIMARY).a();
        Fonts.e.a(matrices, (Text) GradientUtil.a("Delta Client", primary, 5.0f, 0.5f), centerX - (titleWidth / 2.0f), titleY + 1.5f, 12.0f, 0.0f, open);
        Fonts.e.a(matrices, "1.21.4", centerX - (Fonts.e.a("1.21.4", 12.0f) / 2.0f), titleY + 15.0f, 12.0f, ColorUtil.a(255, 255, 255, (int) (160.0f * open)));
        matrices.pop();
    }

    private void a(DrawContext context, int width, int height) {
        if (!this.n) {
            return;
        }
        float elapsed = o();
        float fadeIn = MathHelper.clamp(elapsed / SPLASH_FADE_IN, 0.0f, 1.0f);
        float fadeOut = 1.0f - MathHelper.clamp((elapsed - SPLASH_FADE_OUT_AT) / SPLASH_FADE_OUT, 0.0f, 1.0f);
        float alpha = MathHelper.clamp(EasingList.y.ease(fadeIn) * EasingList.y.ease(fadeOut), 0.0f, 1.0f);
        if (alpha <= 0.001f) {
            return;
        }
        Draw2DProcessor draw = Delta.h().d().i();
        MatrixStack matrices = context.getMatrices();
        draw.a(matrices, 0.0f, 0.0f, width, height, 0.0f, ColorUtil.a(0, 0, 0, (int) (200.0f * alpha)));
        float size = 8.75f;
        float x = (width - Fonts.e.a(SPLASH_TEXT, size)) * 0.5f;
        float y = ((height * 0.5f) - 5.0f) + ((1.0f - EasingList.y.ease(fadeIn)) * 6.0f);
        float typed = SPLASH_TEXT.length() * MathHelper.clamp((elapsed - SPLASH_TYPE_START) / SPLASH_TYPE_TIME, 0.0f, 1.0f);
        int shown = Math.min((int) typed, SPLASH_TEXT.length());
        String head = SPLASH_TEXT.substring(0, shown);
        if (shown > 0) {
            Fonts.e.a(matrices, head, x, y, size, ColorUtil.a(255, 255, 255, (int) (255.0f * alpha)));
        }
        if (shown >= SPLASH_TEXT.length()) {
            return;
        }
        float headWidth = Fonts.e.a(head, size);
        float fraction = EasingList.p.ease(typed - shown);
        String next = String.valueOf(SPLASH_TEXT.charAt(shown));
        Fonts.e.a(matrices, next, x + headWidth, y, size, ColorUtil.a(255, 255, 255, (int) (255.0f * alpha * fraction)));
        float blink = (float) ((Math.sin(elapsed / 140.0f) + 1.0d) * 0.5d);
        draw.a(matrices, x + headWidth + (Fonts.e.a(next, size) * fraction), y - 0.5f, 0.7f, size, 0.0f, ColorUtil.a(255, 255, 255, (int) (170.0f * alpha * (0.4f + (0.6f * blink)))));
    }

    private float o() {
        return System.currentTimeMillis() - this.m;
    }

    private boolean q() {
        return !this.n || o() >= SPLASH_FADE_OUT_AT;
    }

    private boolean p() {
        return this.n && o() < SPLASH_FADE_OUT_AT;
    }
}
