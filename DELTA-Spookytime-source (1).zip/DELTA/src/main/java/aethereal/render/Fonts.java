package aethereal.render;

import aethereal.render.Font;

import lombok.Generated;

public class Fonts {
    public static final Font a = Font.a().a("icons").a();
    public static final Font b = Font.a().a("sf_regular").a();
    public static final Font c = Font.a().a("onest_regular").a();
    public static final Font d = Font.a().a("sf_medium").a();
    public static final Font e = Font.a().a("gt_regular").a();

    @Generated
    private Fonts() {
        throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
    }
}
